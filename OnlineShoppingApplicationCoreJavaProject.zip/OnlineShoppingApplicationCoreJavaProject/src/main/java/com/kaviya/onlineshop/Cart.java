package com.kaviya.onlineshop;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class Cart 
{

	private ArrayList<Integer> pid=new ArrayList<Integer>();
	private ArrayList<String> pname=new ArrayList<String>();
	private ArrayList<String> ptype=new ArrayList<String>();
	private ArrayList<Integer> qpur=new ArrayList<Integer>();
	private ArrayList<Float> qprice=new ArrayList<Float>();
	public ArrayList<Integer> getpid()throws IOException
	{
		return pid;
	}
	public ArrayList<String> getpname()throws IOException
	{
		return pname;
	}
	public ArrayList<Integer> getpqty()throws IOException
	{
		return qpur;
	}
	public ArrayList<Float> getprice()throws IOException
	{
		return qprice;//quantity price
	}
	public void addToCart(int p_id,String p_name,String p_type,int quantPur,float quantPrice)throws IOException
	{
		pid.add(p_id);
		pname.add(p_name);
		ptype.add(p_type);
		qpur.add(quantPur);
		qprice.add(quantPrice);
	}
	public void viewCart()throws IOException
	{
		int total=pid.size();
		if(total!=0)
		{
			System.out.println("YOUR CART IS : \n");
			int index;
			System.out.println("***********************************************************************************************************************\n");
			System.out.printf("%-20s \t %-20s \t %-20s \t %-20s \t %-20s\n", "Product_ID","Product_Name","Product_Type","Quantity_Purchased","Total_Price");
			System.out.println("***********************************************************************************************************************\n");
			for(index=0;index<total;index++)
			{
				System.out.printf("%-20d \t %-20s \t %-20s \t %-20d \t %-20f\n",pid.get(index),pname.get(index),ptype.get(index),qpur.get(index),qprice.get(index) );
			}
			System.out.println("***********************************************************************************************************************\n");
		}
		else
			System.out.println("CART IS EMPTY !");

	}
	public void removeFromCart(int p_id)throws IOException
	{
		int res;
		int cart=-1;
		int prevq=0;
		int newq=0;

		res=pid.indexOf(p_id);

		if(res==-1)
			System.out.println("YOU HAVE NOT PURCHASED THIS PRODUCT !");
		else
		{
			pid.remove(res);
			pname.remove(res);
			ptype.remove(res);
			qprice.remove(res);
			try
			{
				Connection connection=ShoppingCustomConnection.getCustConnection();
				PreparedStatement pstatement=connection.prepareStatement("select Quantity from products where productID=?");
				pstatement.setString(1, Integer.toString(p_id));
				ResultSet rs=pstatement.executeQuery();

				while(rs.next())
				{
					prevq=Integer.parseInt(rs.getString(1));
				}

				newq=prevq+qpur.get(res);
				qpur.remove(res);
				PreparedStatement preparesta2=connection.prepareStatement("update products set Quantity=? where productID=?");
				preparesta2.setString(1,Integer.toString(newq));
				preparesta2.setString(2, Integer.toString(p_id));
				cart=preparesta2.executeUpdate();
			}
			catch(Exception e)
			{
				System.out.println(e.getMessage());
			}
			if(cart!=0)
				System.out.println("CART UPDATED SUCCESSFULLY !");
		}

	}
	public void cancelCart()throws IOException
	{
		try
		{
			int prevq=0;
			int newq=0;
			Connection connection=ShoppingCustomConnection.getCustConnection();
			PreparedStatement prepareS=connection.prepareStatement("update products set Quantity=? where productId=?");
			int index;
			int cart;
			for(index=0;index<pid.size();index++)
			{
				PreparedStatement prepareS1=connection.prepareStatement("select Quantity from products where productID=?");
				prepareS1.setString(1, Integer.toString(pid.get(index)));

				ResultSet rs=prepareS1.executeQuery();

				while(rs.next())
				{
					prevq=Integer.parseInt(rs.getString(1));
				}
				newq=prevq+qpur.get(index);

				prepareS.setString(1, Integer.toString(newq));
				prepareS.setString(2, Integer.toString(pid.get(index)));
				cart=prepareS.executeUpdate();

				if(cart==0)
					System.out.println("PRODUCT NOT UPDATED BACK TO PRODUCTS TABLE !");
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}
