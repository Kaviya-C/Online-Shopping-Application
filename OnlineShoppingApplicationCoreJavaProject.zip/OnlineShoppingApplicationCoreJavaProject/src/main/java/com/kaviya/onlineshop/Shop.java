package com.kaviya.onlineshop;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class Shop  
{
	static int ADMINID;
	static int CUSTID;
	public static void main(String args[]) throws IOException
	{
		DatabaseConnection.makeDatabase();

		BufferedReader bufferR=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("WELCOME TO ONLINE SHOPPING SYSTEM\n");
		int choice;
		do
		{
			System.out.println("*****************************************************\n");
			System.out.println("1 - REGISTER AS ADMIN");
			System.out.println("2 - REGISTER AS CUSTOMER");
			System.out.println("3 - LOGIN TO SYSTEM");
			System.out.println("4 - EXIT");
			System.out.println("*****************************************************\n");


			System.out.print("Enter choice : ");
			choice=Integer.parseInt(bufferR.readLine());

			if(choice==1)
				registerAdmin();

			else if(choice==2)
				registerCustomer();

			else if(choice==3)
				loginSystem();

			else if(choice==4)
				System.out.println("Thanks for Your TIME..!! ");

			else
				System.out.println("Wrong choice");
		}while(choice!=4);

	}


	static void loginSystem()throws IOException
	{
		String chc;
		BufferedReader bufferR=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("\nWELCOME TO LOGIN PAGE\n");
		System.out.println("*****************************************************\n");

		//selecting data from login info table

		ArrayList<Integer> id=new ArrayList<Integer>();
		ArrayList<String> pass=new ArrayList<String>();
		ArrayList<Character> type=new ArrayList<Character>();

		try
		{
			int userId;
			String password;
			char proof=' ';
			Connection connection=ShoppingCustomConnection.getCustConnection();
			PreparedStatement ps=connection.prepareStatement("select * from logininfo");
			ResultSet resultSet=ps.executeQuery();
			while(resultSet.next())
			{
				id.add(Integer.parseInt(resultSet.getString("userID")));
				pass.add(resultSet.getString("password"));
				type.add((resultSet.getString("userType")).charAt(0));
			}

			/*System.out.println(id);
			System.out.println(pass);
			System.out.println(type);*/

			int flag1=0,flag2=0;
			int f1,f2;
			do
			{
				System.out.print("Enter USER ID : ");
				userId=Integer.parseInt(bufferR.readLine());
				System.out.print("Enter PASSWORD : ");
				password=bufferR.readLine();

				f1=id.indexOf(userId);

				f2=pass.indexOf(password);

				if(f1==f2 && (f1!=-1 && f2!=-1))
				{
					flag1=1;
					flag2=1;
				}

				if(flag1==0 || flag2==0)
				{
					System.out.println("INVALID CREDENTIALS , ENTER AGAIN !");
					System.out.print("Do you want to continue ( Yes to continue , No for stop)");
					chc=bufferR.readLine();
					if(chc.equalsIgnoreCase("No"))
						break;
				}

			}while(flag1==0 || flag2==0);

			if(flag1==1 && flag2==1)
			{
				proof=type.get(id.indexOf(userId));
			}
			//System.out.println(tp);
			//continue the code here........

			if(proof=='A')// A for admin
			{
				Admin admin=new Admin(userId,password);
				admin.AdminPage();
			}
			else if(proof=='C') // C for customer
			{
				Customer customer=new Customer(userId,password);
				customer.CustomerPage();
			}

		}
		catch(Exception e)
		{
			//System.out.println(e);
			e.printStackTrace();
		}

	}
	public static boolean ValidMobileNo(String contactNo) 
	{
		Pattern pattern=Pattern.compile("(0/91)?[6-9][0-9]{9}");
		Matcher result=pattern.matcher(contactNo);
		if(contactNo==null)
		{
			return false;
		}
		return (result.matches());
	}

	public static boolean validEmail(String mail)
	{
		String regex = "^[\\w!#$%&'*+/=?`{|}~^-]+"
				+ "(?:\\.[\\w!#$%&'*+/=?`{|}~^-]+)*@"
				+ "(?:[a-zA-Z0-9-]+\\.)"
				+ "+[a-zA-Z]{2,6}";  
		Pattern pattern=Pattern.compile(regex);
		Matcher result=pattern.matcher(mail);
		if(mail==null)
		{
			return false;
		}
		return (result.matches());
	}

	public static boolean validPassword(String password) {
		String regex="^(?=.*[0-9])"
				+ "(?=.*[a-z])(?=.*[A_Z])"
				+ "(?=.*[@#$%^&-+=()])"
				+ "(?=\\S+$).{8,20}$";
		Pattern pattern=Pattern.compile(regex);
		if(password==null)
		{
			return false;
		}
		Matcher result =pattern.matcher(password);
		return result.matches();
	}
	static void registerAdmin()throws IOException
	{
		BufferedReader bufferR=new BufferedReader(new InputStreamReader(System.in));
		String password,name,contact,address,email;
		int age;
		System.out.println("\nWELCOME TO ADMIN REGISTRATION PAGE\n");
		System.out.println("*****************************************************\n");

		setAdminId();

		System.out.println("ADMIN ID = "+ADMINID);

		System.out.println("\n\tPASSWORD FORMAT: 8 characters to 20 (mixed of Upper,lower Case,digits,special character)"
				+ "\n\t\t -!-!-!-!- WARNING: PASSWORD DOESN'T CONTAIN SPACE -!-!-!-!- \n");

		System.out.print("Enter password = ");
		password=bufferR.readLine();
		if(validPassword( password))
		{
			System.out.print("Enter Name = ");
			name=bufferR.readLine();

			System.out.print("Enter age = ");
			age=Integer.parseInt(bufferR.readLine());
			if(age>17 && age<=60)
			{
				System.out.print("Enter contact number = ");
				contact=bufferR.readLine();
				if(ValidMobileNo(contact))
				{
					System.out.print("Enter address = ");
					address=bufferR.readLine();

					System.out.print("Enter email = ");
					email=bufferR.readLine();
					if(validEmail(email))
					{

						try
						{
							Connection connection=ShoppingCustomConnection.getCustConnection();
							PreparedStatement ps=connection.prepareStatement("insert into adminInfo(AdminID,Name,Age,Email,Address,ContactNumber) values(?,?,?,?,?,?)");
							PreparedStatement ps1=connection.prepareStatement("insert into loginInfo(userID,password,userType) values(?,?,?)");

							ps.setString(1, Integer.toString(ADMINID));
							ps.setString(2, name);

							ps.setString(3,Integer.toString(age));
							ps.setString(4, email);
							ps.setString(5, address);
							ps.setString(6, contact);

							ps1.setString(1, Integer.toString(ADMINID));
							ps1.setString(2,password);
							ps1.setString(3, Character.toString('A'));

							int adminInfo=ps.executeUpdate();

							int logInfo=ps1.executeUpdate();
							if(adminInfo>0 && logInfo>0)
								System.out.println("REGISTRATION DONE SUCCESSFULLY !\n");

							else
								System.out.println("REGISTRATION FAILED \n");
						}

						catch(Exception e)
						{
							System.out.println(e.getMessage());
						}
					}
					else
						System.out.println("Registration CANCELLED! Entered MAIL-ID was not in proper format");
				}
				else
					System.out.println("Registration CANCELLED! Entered PHONENUMBER was incorrect");
			}
			else
				System.out.println("Registration CANCELLED !Your AGE is BELOW 18 Or GREATER THAN 60");
		}
		else
			System.out.println("Registration CANCELLED! Entered PASSWORD was not in proper format");
	}

	static void registerCustomer()throws IOException
	{
		BufferedReader bufferR=new BufferedReader(new InputStreamReader(System.in));
		String password,name,phone,address,email;
		int age;
		System.out.println("\nWELCOME TO CUSTOMER REGISTRATION PAGE\n");
		System.out.println("*****************************************************\n");
		setCustId();
		System.out.println("CUSTOMER ID = "+CUSTID);

		System.out.println("\n\tPASSWORD FORMAT: 8 characters to 20 (mixed of Upper,lower Case,digits,special character)"
				+ "\n\t\t -!-!-!-!- WARNING: PASSWORD DOESN'T CONTAIN SPACE -!-!-!-!- \n");

		System.out.print("Enter password = ");
		password=bufferR.readLine();
		if(validPassword( password))
		{
			System.out.print("Enter Name = ");
			name=bufferR.readLine();

			System.out.print("Enter age = ");
			age=Integer.parseInt(bufferR.readLine());

			if(age>17 && age<=60) 
			{
				System.out.print("Enter contact number = ");
				phone=bufferR.readLine();

				if(ValidMobileNo(phone))
				{
					System.out.print("Enter address = ");
					address=bufferR.readLine();

					System.out.print("Enter email = ");
					email=bufferR.readLine();
					if(validEmail(email))
					{
						//inserting data into database
						try
						{
							Connection connection=ShoppingCustomConnection.getCustConnection();
							PreparedStatement ps=connection.prepareStatement("insert into custInfo(CustID,Name,Age,Email,Address,ContactNumber) values(?,?,?,?,?,?)");
							PreparedStatement ps1=connection.prepareStatement("insert into loginInfo(userID,password,userType) values(?,?,?)");
							ps.setString(1, Integer.toString(CUSTID));
							ps.setString(2, name);
							ps.setString(3,Integer.toString(age));
							ps.setString(4, email);
							ps.setString(5, address);
							ps.setString(6, phone);
							ps1.setString(1, Integer.toString(CUSTID));
							ps1.setString(2,password);
							ps1.setString(3, Character.toString('C'));
							int custInfo=ps.executeUpdate();
							int loginInfo=ps1.executeUpdate();
							if(custInfo>0 && loginInfo>0)
								System.out.println("REGISTRATION DONE SUCCESSFULLY !\n");
							else
								System.out.println("REGISTRATION FAILED !\n");
						}
						catch(Exception e)
						{
							System.out.println(e);
						}
					}
					else
						System.out.println("Registration CANCELLED! Entered MAIL-ID was not in proper format");
				}
				else
					System.out.println("Registration CANCELLED! Entered PHONENUMBER was incorrect");
			}
			else
				System.out.println("Registration CANCELLED !Your AGE is BELOW 18 Or GREATER THAN 60");
		}
		else
			System.out.println("Registration CANCELLED! Entered PASSWORD was not in proper format");
	}

	static void setCustId()
	{
		try
		{
			Connection connection=ShoppingCustomConnection.getCustConnection();
			PreparedStatement ps=connection.prepareStatement("select CustID from custinfo");
			ResultSet rs=ps.executeQuery();
			//for customer id should be start from 200 
			int custStart=199;
			while(rs.next()) {
				custStart=Integer.parseInt(rs.getString("CustID"));
			}
			CUSTID=custStart+1;
		}
		catch(Exception e)
		{
			e.printStackTrace();
			//System.out.println(e);
		}
	}
	static void setAdminId()
	{
		try
		{
			Connection connection=ShoppingCustomConnection.getCustConnection();
			PreparedStatement ps=connection.prepareStatement("select AdminID from admininfo");
			ResultSet rs=ps.executeQuery();

			//for admin id should be start from 100..!

			int adminStart=99;
			while(rs.next()) {
				adminStart=Integer.parseInt(rs.getString("AdminID"));
			}
			ADMINID=adminStart+1;
		}
		catch(Exception e)
		{
			//e.printStackTrace();
			System.out.println(e.getMessage());
		}
	}
}
