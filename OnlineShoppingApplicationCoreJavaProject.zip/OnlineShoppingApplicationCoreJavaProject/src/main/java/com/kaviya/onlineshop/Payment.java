package com.kaviya.onlineshop;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Payment 
{
	Bill customerBill;
	public int billPaid_f=0;
	private Cart customerCart;

	Payment(Cart cart1,String custName,String b_add,String custPhn)throws IOException
	{
		customerCart=cart1;
		customerBill=new Bill(custName,b_add,custPhn,customerCart.getpid(),
				customerCart.getpname(),customerCart.getpqty(),customerCart.getprice());
		billPaid_f=0;
	}
	public void paymentPage()throws IOException
	{
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("WELCOME TO PAYMENTS PAGE\n");
		int option;
		do
		{
			System.out.println("*****************************************\n");
			System.out.println("1 - PAY BILL");
			System.out.println("2 - DISPLAY BILL");
			System.out.println("3 - EXIT");
			System.out.println("*****************************************\n");

			System.out.print("Enter ur choice : ");
			
			option=Integer.parseInt(br.readLine());
			switch(option)
			{
			case 1:
				customerBill.displayBill();
				System.out.println("\nENTER AMOUNT TO PAY = ");
				float flag;
				flag=Float.parseFloat(br.readLine());

				while(flag<customerBill.total_amount || flag>customerBill.total_amount)
				{
					System.out.println("Invalid amount entered !");
					System.out.println("Enter valid amount : ");
					flag=Float.parseFloat(br.readLine());
				}

				customerBill.addToDatabase();
				System.out.println("BILL PAID SUCCESSFULLY !");
				billPaid_f=1;
				option=3;
				break;
			case 2:
				customerBill.displayBill();
				break;
			case 3:
				System.out.println("-!-!-!-!-Thank you-!-!-!-!-*May your day Be BRIGHT and BEAUTIFUL*");
				break;
			default:
				System.out.println("Wrong choice");
				break;
			}

		}while(option!=3);

	}
}
