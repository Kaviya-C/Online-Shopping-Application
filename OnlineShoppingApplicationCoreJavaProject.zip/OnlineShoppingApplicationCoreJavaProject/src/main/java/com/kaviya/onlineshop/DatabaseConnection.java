package com.kaviya.onlineshop;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class DatabaseConnection 
{
	static String root;

	public static void makeDatabase()throws IOException
	{
		//creating a table return 0 for execute update
		int table;
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			int flag=1;
			BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
			System.out.println("CONNECTING TO DATABASE.......");
			do
			{
				System.out.print("ENTER ROOT PASSWORD = ");
				root=br.readLine();
				try
				{
					Connection check=DriverManager.getConnection("jdbc:mysql://localhost:3306","root",root);
					flag=1;
				}
				catch(Exception e)
				{
					flag=0;
					System.out.println("WRONG PASSWORD ENTERED ! ENTER AGAIN !");
				}
			}while(flag==0);

			PreparedStatement prepState;
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306","root",root);

			//creating database onlineshop

			prepState=con.prepareStatement("create database onlineshop");
			table=prepState.executeUpdate();

			// System.out.println(x);
			/*if(x!=0)
				System.out.println("DATABASE CREATED SUCCESSFULLY......");*/


			//selecting database onlineshop
			prepState=con.prepareStatement("use onlineshop");
			table=prepState.executeUpdate();
			//System.out.println(x);
			/*if(x==0)
				System.out.println("DATABASE SELECTED SUCCESSFULLY......");*/

			//creating table admininfo
			prepState=con.prepareStatement("create table admininfo ( AdminId int not null, Name varchar(20) not null, Age int not null, Email varchar(30) not null, Address varchar(30) not null, ContactNumber varchar(11) not null, primary key(AdminID) )");
			table=prepState.executeUpdate();
			//System.out.println(x);
			/*if(x==0)
				System.out.println("TABLE admininfo CREATED SUCCESSFULLY......");*/

			//creating table custinfo
			prepState=con.prepareStatement("create table custinfo ( CustId int not null, Name varchar(20) not null, Age int not null, Email varchar(30) not null, Address varchar(30) not null, ContactNumber varchar(11) not null, primary key(CustID) )");
			table=prepState.executeUpdate();
			//System.out.println(x);
			/*if(x==0)
				System.out.println("TABLE custinfo CREATED SUCCESSFULLY......");*/

			//creating table logininfo
			prepState=con.prepareStatement("create table logininfo ( userID int not null, password varchar(20) not null, userType char not null, primary key(userID) )");
			table=prepState.executeUpdate();
			//System.out.println(x);
			/*if(x==0)
				System.out.println("TABLE logininfo CREATED SUCCESSFULLY......");*/

			//creating table products
			prepState=con.prepareStatement("create table products (  productID int not null, Name varchar(20) not null, Type varchar(20) not null, Quantity int not null, Price float not null, primary key(productID) )");
			table=prepState.executeUpdate();
			//System.out.println(x);
			/*if(x==0)
				System.out.println("TABLE products CREATED SUCCESSFULLY......");*/

			//creating table bills
			prepState=con.prepareStatement("create table bills ( bill_id int not null, cust_name varchar(20) not null, bill_addr varchar(30) not null, total_amt float not null, primary key(bill_id) )");
			table=prepState.executeUpdate();
			//System.out.println(x);
			/*if(x==0)
				System.out.println("TABLE bills CREATED SUCCESSFULLY......");*/

		}
		catch(Exception e)
		{
			System.out.println("");
		}
		System.out.println("DATABASE CONNECTED SUCCESSFULLY.....\n");
	}

}
