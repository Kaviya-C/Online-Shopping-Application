package com.kaviya.onlineshop;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class Customer extends Shop {

	Connection connection=null;


	private int customerID;
	private String customerPass;
	private Cart customerCart=new Cart();
	private int cartFlag=0;
	private int billPaidFlag=0;
	private int checkFlag=-1;

	private ArrayList<Integer> pid=new ArrayList<Integer>();
	private ArrayList<String> name=new ArrayList<String>();
	private ArrayList<String> type=new ArrayList<String>();
	private ArrayList<Integer> qty=new ArrayList<Integer>();
	private ArrayList<Float> price=new ArrayList<Float>();

	private int products_Check;

	Customer(int custID,String passw)
	{
		customerID=custID;
		customerPass=passw;
		customerCart=new Cart();
		billPaidFlag=0;
		cartFlag=0;
	}
	public void CustomerPage()throws IOException
	{
		BufferedReader bufferR=new BufferedReader(new InputStreamReader(System.in));
		products_Check=this.initializeProducts(); //this statement always runs
		System.out.println("WELCOME TO CUSTOMER SECTION\n");
		int choice;
		do
		{
			System.out.println("*****************************************************\n");
			System.out.println("1 - VIEW PRODUCTS LIST");
			System.out.println("2 - SEARCH A PRODUCT NAMEWISE");
			System.out.println("3 - SEARCH PRODUCTS TYPEWISE");
			System.out.println("4 - ADD PRODUCT TO CART");
			System.out.println("5 - REMOVE PRODUCT FROM CART");
			System.out.println("6 - VIEW CART");
			System.out.println("7 - PROCEED TO PAYMENT");
			System.out.println("8 - EDIT PROFILE");
			System.out.println("9 - LOGOUT FROM SYSTEM");
			System.out.println("*****************************************************\n");
			System.out.print("Enter choice : ");
			choice=Integer.parseInt(bufferR.readLine());
			switch(choice)
			{
			case 1:
				this.viewProducts();
				break;
			case 2:
				this.searchNameWise();
				break;
			case 3:
				this.searchTypeWise();
				break;
			case 4:
				this.addProducts();
				break;
			case 5:
				int rem;
				System.out.print("ENTER PRODUCT ID TO REMOVE FROM CART = ");
				rem=Integer.parseInt(bufferR.readLine());
				customerCart.removeFromCart(rem);
				this.updateArrayList();
				break;
			case 6:
				customerCart.viewCart();
				break;
			case 7:
				this.proceedPayment(customerCart);
				break;
			case 8:
				editProfile(customerID);
				break;
			case 9,0:
				choice=this.checkExit();
				break;
			default:
				System.out.println("Wrong choice");
				break;
			}
		}while(choice!=9);
	}
	private int checkExit()throws IOException
	{
		if(cartFlag==1)
		{
			BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
			String repeat;
			System.out.println("YOU HAVE A PENDING CART !");
			System.out.print("DO YOU WANT TO MAKE PAYMENT ( PRESS Yes ) ELSE CANCEL THE CART ( PRESS No) : ");
			repeat=br.readLine();
			if(repeat.equalsIgnoreCase("Yes"))
			{
				proceedPayment(customerCart);
				if(billPaidFlag!=1 && checkFlag==-1)
					return -1;
				else
					return 0;
			}
			else
			{
				customerCart.cancelCart();
				customerCart=new Cart();
				cartFlag=0;
				billPaidFlag=0;
			}
		}
		System.out.println("THANK YOU !Visit Again.....!!");
		return 9; 	//to exit the customerPage

	}
	private void proceedPayment(Cart cart1)throws IOException
	{
		if(cartFlag==1)
		{
			String c_name="";
			String b_add="";
			String c_phn="";
			try
			{
				connection=ShoppingCustomConnection.getCustConnection();
				PreparedStatement ps=connection.prepareStatement("select * from custinfo where custID=?");
				ps.setString(1, Integer.toString(customerID));
				ResultSet rs=ps.executeQuery();
				while(rs.next())
				{
					c_name=rs.getString(2);
					b_add=rs.getString(5);
					c_phn=rs.getString(6);
				}

			}
			catch(Exception e)
			{
				System.out.println(e);
			}
			Payment p=new Payment(cart1,c_name,b_add,c_phn);
			p.paymentPage();

			if(p.billPaid_f==1)
				billPaidFlag=1;

			if(billPaidFlag==1)
			{
				customerCart=new Cart();
				cartFlag=0;
				billPaidFlag=0;
				checkFlag=-2;
			}
		}
		else
			System.out.println("CART IS EMPTY! ");
	}
	//the  below functions are of private use only , not to be used by customer class
	private void updateArrayList()throws IOException
	{
		pid.clear();
		name.clear();
		type.clear();
		qty.clear();
		price.clear();
		initializeProducts();
	}
	private int searchProd(int x)throws IOException //for searching product and retrieving the available quantity
	{
		int res=pid.indexOf(x);
		if(res!=-1)
		{
			return qty.get(res);
		}
		else
		{
			return -1;
		}
	}
	private void updateQty(int quantity,int prodId)throws IOException //productID ---> quantity to be subtracted
	{
		try
		{
			int res=pid.indexOf(prodId);
			int min=qty.get(res);
			if(min-quantity>0)
			{
				qty.set(res, min-quantity);
			}
			else
				qty.set(res,0);

			connection=ShoppingCustomConnection.getCustConnection();
			PreparedStatement ps=connection.prepareStatement("update products set Quantity=? where productID=?");
			ps.setString(1,Integer.toString(qty.get(res)));
			ps.setString(2, Integer.toString(prodId));
			int updation=ps.executeUpdate();
			if(updation==0)
				System.out.println("PRODUCT UPDATION FAILED !");
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
	}
	//*******************************************************************************************
	private void addProducts()throws IOException
	{
		BufferedReader bufferR=new BufferedReader(new InputStreamReader(System.in));
		String repeated;
		do
		{
			int p_id;
			String p_name,p_type;
			float p_price;
			int q_pur;

			int q_avail;
			System.out.print("ENTER PRODUCT ID TO ADD TO CART = ");
			p_id=Integer.parseInt(bufferR.readLine());
			q_avail=searchProd(p_id);
			if(q_avail==-1)
				System.out.println("PRODUCT NOT FOUND !");
			else
			{
				System.out.println("QUNATITY AVAILABLE = "+q_avail);
				System.out.println("ENTER QUANTITY TO PURCHASE = ");
				q_pur=Integer.parseInt(bufferR.readLine());
				if(q_pur>q_avail)
					System.out.println("STOCK NOT AVAILABLE");
				else
				{
					updateQty(q_pur,p_id);

					//adding product to cart code begins below
					p_name=name.get(pid.indexOf(p_id));
					p_type=type.get(pid.indexOf(p_id));
					p_price=(float)(q_pur*(price.get(pid.indexOf(p_id))));

					customerCart.addToCart(p_id, p_name, p_type, q_pur, p_price);
					cartFlag=1;
				}

			}
			System.out.print("DO YOU WANT TO ADD the PRODUCT to CART?? Type( yes else type no)");
			repeated=bufferR.readLine();
		}while(repeated.equalsIgnoreCase("Yes"));
	}
	private int initializeProducts()throws IOException //return 1 if products are available orr 0 if not avaialable
	{
		int row=0;
		try
		{
			connection=ShoppingCustomConnection.getCustConnection();
			PreparedStatement ps=connection.prepareStatement("select * from products",ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
			ResultSet rs=ps.executeQuery();
			//*******
			//for counting the number of rows in result set
			if(rs.last()) {
				row=rs.getRow();
				//System.out.println("Row get="+x);
				rs.beforeFirst();
			}
			//*******
			if(row==0)
				return 0;
			else
			{
				while(rs.next())
				{
					pid.add(Integer.parseInt(rs.getString(1)));
					name.add(rs.getString(2));
					type.add(rs.getString(3));
					qty.add(Integer.parseInt(rs.getString(4)));
					price.add(Float.parseFloat(rs.getString(5)));
				}
			}

		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return row;
	}
	private void viewProducts()throws IOException
	{
		if(products_Check==0)
			System.out.println("PRODUCTS NOT AVAILABLE !");
		else
		{
			int total;
			total=pid.size();
			int start;
			System.out.println("***********************************************************************************************************************\n");
			System.out.printf("%-20s \t %-20s \t %-20s \t %-20s \t %-20s\n", "Product_ID","Product_Name","Product_Type","Product_Quantity","Product_Price");
			System.out.println("***********************************************************************************************************************\n");
			for(start=0;start<total;start++)
			{
				if(qty.get(start)!=0)
					System.out.printf("%-20d \t %-20s \t %-20s \t %-20d \t %-20f\n",pid.get(start),name.get(start),type.get(start),qty.get(start),price.get(start) );
				else
					System.out.printf("%-20d \t %-20s \t %-20s \t %-20s \t %-20f\n",pid.get(start),name.get(start),type.get(start),"NOT IN STOCK",price.get(start) );
			}
			System.out.println("***********************************************************************************************************************\n");
		}
	}
	private void searchNameWise()throws IOException
	{
		if(products_Check==0)
			System.out.println("PRODUCTS NOT AVAILABLE !");
		else
		{
			BufferedReader bufferR=new BufferedReader(new InputStreamReader(System.in));
			String prodName;
			int res;
			String repeated;
			do
			{
				System.out.print("ENTER PRODUCT NAME TO SEARCH : ");
				prodName=bufferR.readLine();
				res=name.indexOf(prodName);
				if(res==-1)
					System.out.println("PRODUCT NOT FOUND !");
				else
				{
					System.out.println("PRODUCT DETAILS ARE :\n");
					System.out.printf("PRODUCT ID         = %-5d\n",pid.get(res));
					System.out.printf("PRODUCT NAME       = %-20s\n",name.get(res));
					System.out.printf("PRODUCT TYPE       = %-20s\n", type.get(res));
					if(qty.get(res)!=0)
						System.out.printf("QUANTITY AVAILABLE = %-5d\n", qty.get(res));
					else
						System.out.printf("QUANTITY AVAILABLE = %-5s\n", "NOT IN STOCK");
					System.out.printf("PRODUCT PRICE      = %-10f\n",price.get(res));
				}
				System.out.print("Type Yes to continue , No for exit : ");
				repeated=bufferR.readLine();

			}while(repeated.equalsIgnoreCase("Yes"));

		}
	}
	private void searchTypeWise()throws IOException
	{
		if(products_Check==0)
			System.out.println("PRODUCTS NOT AVAILABLE !");
		else
		{
			BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
			String prodType;
			int res;
			String repeated;
			do
			{
				System.out.print("ENTER PRODUCT TYPE TO SEARCH : ");
				prodType=br.readLine();
				res=type.indexOf(prodType);
				if(res==-1)
					System.out.println("PRODUCT NOT FOUND !");
				else
				{
					System.out.println("PRODUCTS AVAILABLE ARE : \n");
					System.out.println("***********************************************************************************************************************\n");
					System.out.printf("%-20s \t %-20s \t %-20s \t %-20s \t %-20s\n", "Product_ID","Product_Name","Product_Type","Product_Quantity","Product_Price");
					System.out.println("***********************************************************************************************************************\n");
					res=pid.size();
					for(int index=0;index<res;index++)
					{
						if(prodType.equalsIgnoreCase(type.get(index)))
						{
							if(qty.get(index)!=0)
								System.out.printf("%-20d \t %-20s \t %-20s \t %-20d \t %-20f\n",pid.get(index),name.get(index),type.get(index),qty.get(index),price.get(index) );
							else
								System.out.printf("%-20d \t %-20s \t %-20s \t %-20s \t %-20f\n",pid.get(index),name.get(index),type.get(index),"NOT IN STOCK",price.get(index) );
						}
					}
					System.out.println("***********************************************************************************************************************\n");
				}
				System.out.print("PRESS Yes to continue , No for exit : ");
				repeated=br.readLine();

			}while(repeated.equalsIgnoreCase("Yes"));
		}
	}
	private static void editProfile(int custID)throws IOException
	{
		try
		{
			int x=0;
			String repeated;
			Connection connection=ShoppingCustomConnection.getCustConnection();
			BufferedReader bufferR=new BufferedReader(new InputStreamReader(System.in));
			String s="";
			int fc=-1;
			String name="",email="",addr="",contact="",passw="";
			int age=0;
			int choice=0;
			do
			{
				System.out.println("************************************************************");
				System.out.println("1 - EDIT NAME");
				System.out.println("2 - EDIT AGE");
				System.out.println("3 - EDIT EMAIL ID");
				System.out.println("4 - EDIT ADDRESS");
				System.out.println("5 - EDIT CONTACT NUMBER");
				System.out.println("6 - CHANGE PASSWORD");
				System.out.println("7 - EXIT");
				System.out.println("************************************************************");
				System.out.print("Enter choice : ");
				choice=Integer.parseInt(bufferR.readLine());
				switch(choice)
				{
				case 1:
					System.out.print("ENTER NEW NAME : ");
					name=bufferR.readLine();
					s="Name";
					fc=1;
					break;
				case 2:
					System.out.print("ENTER AGE : ");
					age=Integer.parseInt(bufferR.readLine());
					s="Age";
					fc=1;
					break;
				case 3:
					System.out.print("ENTER NEW EMAIL ID : ");
					email=bufferR.readLine();
					s="Email";
					fc=1;
					break;
				case 4:
					System.out.print("ENTER ADDRESS : ");
					addr=bufferR.readLine();
					s="Address";
					fc=1;
					break;
				case 5:
					System.out.print("ENTER NEW CONTACT NUMBER : ");
					contact=bufferR.readLine();
					s="ContactNumber";
					fc=1;
					break;
				case 6:
					System.out.print("ENTER NEW PASSWORD : ");
					passw=bufferR.readLine();
					s="password";
					fc=0;
					break;
				case 7:
					System.out.println("Thank you");
					break;
				default:
					System.out.println("Wrong choice");
					break;
				}
				if(fc==1)
				{
					PreparedStatement ps;
					if(s.equalsIgnoreCase("Name"))
					{
						ps=connection.prepareStatement("update custinfo set Name = ? where custID=?");
						ps.setString(1, name);
						ps.setString(2, Integer.toString(custID));
						x=ps.executeUpdate();
						if(x!=0)
							System.out.println("INFORMATION UPDATED SUCCESSFULLY !");
					}
					else if(s.equalsIgnoreCase("Age"))
					{
						if(age>=18 &&age<=60) {
							ps=connection.prepareStatement("update custinfo set Age = ? where custID=?");
							ps.setString(1, Integer.toString(age));
							ps.setString(2, Integer.toString(custID));
							x=ps.executeUpdate();
							if(x!=0)
								System.out.println("INFORMATION UPDATED SUCCESSFULLY !");
						}
						else
							System.out.println("Oops!!Your AGE is BELOW 18 Or GREATER THAN 60\n");
					}
					else if(s.equalsIgnoreCase("Email"))
					{
						if(validEmail(email))
						{
							ps=connection.prepareStatement("update custinfo set Email = ? where custID=?");
							ps.setString(1,email);
							ps.setString(2, Integer.toString(custID));
							x=ps.executeUpdate();
							if(x!=0)
								System.out.println("INFORMATION UPDATED SUCCESSFULLY !");
						}
						else
							System.out.println("Oops!! Entered MAIL-ID was not in proper format");
					}
					else if(s.equalsIgnoreCase("Address"))
					{
						ps=connection.prepareStatement("update custinfo set Address = ? where custID=?");
						ps.setString(1, addr);
						ps.setString(2, Integer.toString(custID));
						x=ps.executeUpdate();
						if(x!=0)
							System.out.println("INFORMATION UPDATED SUCCESSFULLY !");

					}
					else if(s.equalsIgnoreCase("ContactNumber"))
					{
						if(ValidMobileNo(contact))
						{
							ps=connection.prepareStatement("update custinfo set ContactNumber = ? where custID=?");
							ps.setString(1, contact);
							ps.setString(2, Integer.toString(custID));
							x=ps.executeUpdate();
							if(x!=0)
								System.out.println("INFORMATION UPDATED SUCCESSFULLY !");
						}
						else
							System.out.println("Oops!! Entered PHONENUMBER was incorrect");
					}
					
				}
				else if(fc==0)
				{
					if(validPassword(passw)) {
						PreparedStatement ps=connection.prepareStatement("update logininfo set password=? where userID=?");
						ps.setString(1,passw);
						ps.setString(2, Integer.toString(custID));
						x=ps.executeUpdate();
						if(x!=0)
							System.out.println("PASSWORD CHANGED SUCCESSFULLY !");
					}
					else
						System.out.println("Registration CANCELLED! Entered PASSWORD was not in proper format");
				}
				System.out.print("Do you want to continue to EDIT the details? Type (yes to continue ,or No to stop ) : ");
				repeated=bufferR.readLine();


			}while(repeated.equalsIgnoreCase("Yes"));
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
	}
}
