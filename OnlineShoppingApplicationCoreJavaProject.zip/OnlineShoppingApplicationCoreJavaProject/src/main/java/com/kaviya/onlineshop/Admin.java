package com.kaviya.onlineshop;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;


public class Admin extends Shop 
{
	static Connection connection=null;
	static PreparedStatement pstatement=null;

	private int adminID;
	private String password;

	Admin(int adminId,String passWord)
	{
		adminID=adminId;
		password=passWord;
	}
	public void AdminPage()throws IOException
	{
		BufferedReader bufferReader=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("WELCOME TO ADMIN SECTION\n");
		int choice;
		do
		{
			System.out.println("*****************************************************\n");
			System.out.println("1 - MANAGE PRODUCTS");
			System.out.println("2 - ADD CUSTOMERS");
			System.out.println("3 - REMOVE CUSTOMERS");
			System.out.println("4 - EDIT PROFILE");
			System.out.println("5 - VIEW REGISTERED CUSTOMERS");
			System.out.println("6 - LOGOUT FROM SYSTEM");
			System.out.println("*****************************************************\n");
			System.out.print("Enter choice : ");
			choice=Integer.parseInt(bufferReader.readLine());
			switch(choice)
			{
			case 1:
				Products product=new Products();
				product.ProductsPage();
				break;
			case 2:
				addCustomer();
				break;
			case 3:
				removeCustomer();
				break;
			case 4:
				editProfile(adminID);
				break;
			case 5:
				viewCustomers();
				break;
			case 6:
				System.out.println(" Thank you ");
				break;
			default:
				System.out.println("Wrong choice");
				break;
			}
		}while(choice!=6);

	}
	private static void editProfile(int adminID)throws IOException
	//admin details can be edited in this method..
	{
		try
		{

			int initial=0;
			String repeat;
			Admin.connection=ShoppingCustomConnection.getCustConnection();
			BufferedReader bufferR=new BufferedReader(new InputStreamReader(System.in));
			String field="";
			int result=-1;
			String name="",email="",address="",contact="",password="";
			int age=0;
			int choice=0;
			do
			{
				System.out.println("************************************************************");
				System.out.println("1 - EDIT NAME");
				System.out.println("2 - EDIT AGE");
				System.out.println("3 - EDIT EMAIL ID");
				System.out.println("4 - EDIT ADDRESS");
				System.out.println("5 - EDIT CONTACT NUMBER");
				System.out.println("6 - CHANGE PASSWORD");
				System.out.println("7 - EXIT");
				System.out.println("************************************************************");
				System.out.print("Enter choice : ");
				choice=Integer.parseInt(bufferR.readLine());
				switch (choice)
				{
				case 1:
					System.out.print("ENTER NEW NAME : ");
					name=bufferR.readLine();
					field="Name";
					result=1;
					break;
				case 2:
					System.out.print("ENTER AGE : ");
					age=Integer.parseInt(bufferR.readLine());
					field="Age";
					result=1;
					break;
				case 3:
					System.out.print("ENTER NEW EMAIL ID : ");
					email=bufferR.readLine();
					field="Email";
					result=1;
					break;
				case 4:
					System.out.print("ENTER ADDRESS : ");
					address=bufferR.readLine();
					field="Address";
					result=1;
					break;
				case 5:
					System.out.print("ENTER NEW CONTACT NUMBER : ");
					contact=bufferR.readLine();
					field="ContactNumber";
					result=1;//changing the attributes like name phone address and mail...!
					break;
				case 6:
					System.out.println("\n\tPASSWORD FORMAT: 8 characters to 20 (mixed of Upper,lower Case,digits,special character[@  #  % $ * ])"
							+ "\n\t\t -!-!-!-!- WARNING: PASSWORD DOESN'T CONTAIN SPACE -!-!-!-!- \n");

					System.out.print("ENTER NEW PASSWORD : ");
					password=bufferR.readLine();
					field="password";
					result=0;// changing the password...!
					break;
				case 7:
					System.out.println("Thank you");
					break;
				default:
					System.out.println("Wrong choice");
					break;
				}
				if(result==1)
				{

					if(field.equalsIgnoreCase("Name"))
					{
						pstatement=connection.prepareStatement("update admininfo set Name = ? where AdminID=?");
						pstatement.setString(1, name);
						pstatement.setString(2, Integer.toString(adminID));
						initial=pstatement.executeUpdate();
						if(initial!=0)
							System.out.println("INFORMATION UPDATED SUCCESSFULLY !");

					}
					else if(field.equalsIgnoreCase("Age"))
					{
						if(age>=18 && age<=60)
						{
							pstatement=connection.prepareStatement("update admininfo set Age = ? where AdminID=?");
							pstatement.setString(1, Integer.toString(age));
							pstatement.setString(2, Integer.toString(adminID));
							initial=pstatement.executeUpdate();
							if(initial!=0)
								System.out.println("INFORMATION UPDATED SUCCESSFULLY !");

						}
						else
							System.out.println("We are not updated ur age bcoz Entered AGE was BELOW 18 or ABOVE 60");
					}
					else if(field.equalsIgnoreCase("Email"))
					{
						if(validEmail(email)) 
						{
							pstatement=connection.prepareStatement("update admininfo set Email = ? where AdminID=?");
							pstatement.setString(1,email);
							pstatement.setString(2, Integer.toString(adminID));
							initial=pstatement.executeUpdate();
							if(initial!=0)
								System.out.println("INFORMATION UPDATED SUCCESSFULLY !");

						}
						else
							System.out.println(" We are not updated ur email bcoz entered MAIL-ID was not in proper format");
					}
					else if(field.equalsIgnoreCase("Address"))
					{
						pstatement=connection.prepareStatement("update admininfo set Address = ? where AdminID=?");
						pstatement.setString(1, address);
						pstatement.setString(2, Integer.toString(adminID));
						initial=pstatement.executeUpdate();
						if(initial!=0)
							System.out.println("INFORMATION UPDATED SUCCESSFULLY !");


					}
					else if(field.equalsIgnoreCase("ContactNumber"))
					{
						if(ValidMobileNo(contact))
						{
							pstatement=connection.prepareStatement("update admininfo set ContactNumber = ? where AdminID=?");
							pstatement.setString(1, contact);
							pstatement.setString(2, Integer.toString(adminID));
							initial=pstatement.executeUpdate();
							if(initial!=0)
								System.out.println("INFORMATION UPDATED SUCCESSFULLY !");

						}
						else
						{
							System.out.println("Entered CONTACT NUMBER was not in proper format! Please check again!");
						}
					}
					

				}
				else if(result==0)
				{
					if(validPassword( password))
					{
						pstatement=connection.prepareStatement("update logininfo set password=? where userID=?");
						pstatement.setString(1,password);
						pstatement.setString(2, Integer.toString(adminID));
						initial=pstatement.executeUpdate();
						if(initial!=0)
							System.out.println("PASSWORD CHANGED SUCCESSFULLY !");

					}
					else
						System.out.println("We are not changed ur password, Entered PASSWORD was not in proper format..!");
				}
				System.out.print("Do you want to EDIT the PROFILE again ?( Type yes to continue no to stop ) : ");
				repeat=bufferR.readLine();

			}while(repeat.equalsIgnoreCase("Yes"));
		}
		catch(Exception e)
		{
			System.out.println(e);
			//e.printStackTrace();
		}
	}
	private static void viewCustomers()throws IOException
	{
		int custId,custAge;
		String custName,custEmail,custAddress,custPhone;
		int row=0;
		try
		{
			Admin.connection=ShoppingCustomConnection.getCustConnection();
			pstatement=connection.prepareStatement("select * from custinfo",
					ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
			ResultSet rs=pstatement.executeQuery();

			//*******
			//for counting the number of rows in result set

			if(rs.last()) 
			{
				row=rs.getRow();
				rs.beforeFirst();
			}
			//*******
			if(row==0)
				System.out.println("NO CUSTOMERS AVAIALABLE");
			else
			{
				System.out.println("***********************************************************************************************************************************************\n");
				System.out.printf("%-20s \t %-20s \t %-10s \t %-20s \t %-20s \t %-5s\n","CUSTOMER_ID","NAME","AGE","EMAIL","ADDRESS","CONTACT_NUMBER");
				System.out.println("***********************************************************************************************************************************************\n");
				while(rs.next())
				{
					custId=Integer.parseInt(rs.getString(1));

					custName=rs.getString(2);

					custAge=Integer.parseInt(rs.getString(3));

					custEmail=rs.getString(4);

					custAddress=rs.getString(5);

					custPhone=rs.getString(6);
					//printf----- formating the output it is present in printstream class...
					//   %d--->decimal   %- this mean align in left that"-"
					System.out.printf("%-20d \t %-20s \t %-10d \t %-20s \t %-20s \t %-5s\n",custId,custName,custAge,custEmail,custAddress,custPhone);
				}
				System.out.println("***********************************************************************************************************************************************\n");
			}

		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
	}
	private static void addCustomer()throws IOException
	{
		Shop.registerCustomer();
	}
	private static void removeCustomer()throws IOException
	{
		//delete record from both custinfo and logininfo

		BufferedReader bufferReader=new BufferedReader(new InputStreamReader(System.in));
		int customerInfo=0,loginInfo=0;
		int customerId;
		try
		{
			Admin.connection=ShoppingCustomConnection.getCustConnection();
			PreparedStatement ps=connection.prepareStatement("select * from custinfo"
					,ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
			ResultSet rs=ps.executeQuery();
			//*******
			//for counting the number of rows in result set
			if(rs.last()) 
			{
				customerInfo=rs.getRow();
				rs.beforeFirst();
			}
			//*******
			if(customerInfo==0)
				System.out.println("NO CUSTOMERS AVAIALABLE");
			else
			{
				System.out.print("Enter customer ID to delete : ");
				customerId=Integer.parseInt(bufferReader.readLine());

				PreparedStatement ps1=connection.prepareStatement("delete from custinfo where custID=?");

				PreparedStatement ps2=connection.prepareStatement("delete from logininfo where userID=?");

				ps1.setString(1, Integer.toString(customerId));

				ps2.setString(1, Integer.toString(customerId));

				customerInfo=ps1.executeUpdate();

				loginInfo=ps2.executeUpdate();

				if(customerInfo!=0 && loginInfo!=0)
					System.out.println("CUSTOMER INFO DELETED SUCCESSFULLY !");

				else
					System.out.println("CUSTOMER INFO NOT FOUND !");

			}

		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}

}
