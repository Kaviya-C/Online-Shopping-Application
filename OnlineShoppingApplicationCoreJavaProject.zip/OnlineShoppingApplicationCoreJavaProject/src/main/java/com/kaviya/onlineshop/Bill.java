package com.kaviya.onlineshop;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class Bill
{
	private int bill_id;
	private String cust_name;
	private String bill_addr;
	private String cust_phone;
	public float total_amount;

	private ArrayList<Integer> pid=new ArrayList<Integer>();
	private ArrayList<String> pname=new ArrayList<String>();
	private ArrayList<Integer> qty=new ArrayList<Integer>();
	private ArrayList<Float> price=new ArrayList<Float>();

	Bill(String cname,String billaddress,String custPhone,ArrayList<Integer> p_id,ArrayList<String> p_name,ArrayList<Integer> quantity,ArrayList<Float> priceAmt)throws IOException
	{
		cust_name=cname;
		bill_addr=billaddress;
		cust_phone=custPhone;
		total_amount=0.0f;
		pid=p_id;
		pname=p_name;
		qty=quantity;
		price=priceAmt;
	}
	private void generateBill()throws IOException
	{
		bill_id=setBillId();
		//int x;
		float sum=0.0f;
		int index;
		for(index=0;index<pid.size();index++)
		{
			sum=sum+price.get(index);
		}
		total_amount=sum;
	}
	private static int setBillId()throws IOException
	{
		int bill_ID=2999;
		try
		{
			Connection connection=ShoppingCustomConnection.getCustConnection();
			PreparedStatement ps=connection.prepareStatement("select bill_id from bills");
			ResultSet rs=ps.executeQuery();

			while(rs.next())
			{
				bill_ID=Integer.parseInt(rs.getString(1));
			}

		}
		catch(Exception e)
		{
			System.out.println(e);
		}

		return bill_ID+1;
	}
	public void displayBill()throws IOException
	{
		generateBill();
		int start;
		System.out.println("YOUR BILL IS :\n");
		System.out.println("************************************************************************************************\n");
		System.out.printf("BILL ID                  =  %-5d\n",bill_id);
		System.out.printf("CUSTOMER NAME            =  %-20s\n",cust_name);
		System.out.printf("CUSTOMER CONTACT NUMBER  =  %-20s\n", cust_phone);
		System.out.printf("CUSTOMER ADDRESS         =  %-30s\n", bill_addr);
		System.out.println("************************************************************************************************\n");
		System.out.printf("%-20s \t %-20s \t %-20s \t %-20s\n", "PRODUCT_ID","PRODUCT_NAME","QUANTITY PURCHASED","TOTAL_PRICE");
		for(start=0;start<pid.size();start++)
		{
			System.out.printf("%-20d \t %-20s  \t %-20d \t %-20f\n", pid.get(start),pname.get(start),qty.get(start),price.get(start));
		}
		System.out.println("************************************************************************************************\n");
		System.out.printf("TOTAL AMOUNT PAYABLE = Rs. "+total_amount+"\n");
		System.out.println("************************************************************************************************\n");
	}
	public void addToDatabase()throws IOException
	{
		int bilAddDb;
		try
		{
			Connection connection=ShoppingCustomConnection.getCustConnection();
			PreparedStatement ps=connection.prepareStatement("insert into bills(bill_id,cust_name,bill_addr,total_amt) values(?,?,?,?)");

			ps.setString(1, Integer.toString(bill_id));
			ps.setString(2,cust_name);
			ps.setString(3, bill_addr);
			ps.setString(4, Float.toString(total_amount));
			bilAddDb=ps.executeUpdate();
			if(bilAddDb==0)
				System.out.println("BILL NOT ADDED TO DATABASE !");
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}

}

