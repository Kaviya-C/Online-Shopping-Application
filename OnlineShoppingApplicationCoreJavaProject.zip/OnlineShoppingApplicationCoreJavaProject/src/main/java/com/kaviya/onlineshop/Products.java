package com.kaviya.onlineshop;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;



public class Products 

{
	String repeated;
	private int pid,qty;
	private String name,type;
	private float price;
	public void ProductsPage()throws IOException
	{
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		Products product =new Products();
		System.out.println("\nWELCOME TO PRODUCTS MANAGEMENT PAGE\n");
		int choice;
		do
		{
			System.out.println("*****************************************************\n");
			System.out.println("1 - ADD PRODUCTS");
			System.out.println("2 - REMOVE PRODUCTS");
			System.out.println("3 - ALTER PRODUCT INFO");
			System.out.println("4 - VIEW ALL PRODUCTS");
			System.out.println("5 - SEARCH A PARTICULAR PRODUCT");
			System.out.println("6 - EXIT PAGE");
			System.out.println("*****************************************************\n");
			System.out.print("Enter choice : ");
			choice=Integer.parseInt(br.readLine());
			if(choice==1)
				product.addProducts();
			else if(choice==2)
				product.removeProducts();
			else if(choice==3)
				product.alterProduct();
			else if(choice==4)
				product.viewProducts();
			else if(choice==5)
				product.searchProduct();
			else if(choice==6)
				System.out.println("Thank you");
			else
				System.out.println("Wrong choice ");

		}while(choice!=6);

	}
	private void alterProduct()throws IOException
	{
		int row=0;
		int choice1;
		String repeated_1;
		BufferedReader bufferReader=new BufferedReader(new InputStreamReader(System.in));
		try
		{
			Connection connection=ShoppingCustomConnection.getCustConnection();
			PreparedStatement ps=connection.prepareStatement("select * from products",
					ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
			ResultSet rs=ps.executeQuery();
			//*******
			//for counting the number of rows in result set
			if(rs.last()) 
			{
				row=rs.getRow();
				rs.beforeFirst();
			}
			//*******
			if(row==0)
				System.out.println("NO PRODUCTS AVAIALABLE");
			else
			{
				do
				{
					System.out.print("enter product ID to update info : ");
					pid=Integer.parseInt(bufferReader.readLine());
					int flag=0;
					while(rs.next())
					{
						if(Integer.parseInt(rs.getString(1))==pid)
						{
							flag=1;
							name=rs.getString(2);
							type=rs.getString(3);
							qty=Integer.parseInt(rs.getString(4));
							price=Float.parseFloat(rs.getString(5));
							do
							{
								System.out.println("FETCHED PRODUCT INFO :\n");
								System.out.printf("Product ID   = %-5d\n", pid);
								System.out.printf("Product Name = %-20s\n", name);
								System.out.printf("Product Type = %-20s\n", type);
								System.out.printf("Quantity     = %-5d\n",qty);
								System.out.printf("Price        = %-10f\n", price);
								System.out.println("\n1 - UPDATE PRODUCT NAME\n");
								System.out.println("\n2 - UPDATE PRODUCT TYPE\n");
								System.out.println("\n3 - UPDATE PRODUCT QUANTITY\n");
								System.out.println("\n4 - UPDATE PRICE\n");
								System.out.print("\nEnter choice : ");
								choice1=Integer.parseInt(bufferReader.readLine());
								switch(choice1) 
								{
								case 1:
									System.out.print("ENTER NEW NAME : ");
									name=bufferReader.readLine();
									break;
								case 2:
									System.out.print("ENTER NEW TYPE : ");
									type=bufferReader.readLine();
									break;
								case 3:
									System.out.print("ENTER NEW QUANTITY : ");
									qty=Integer.parseInt(bufferReader.readLine());
									break;
								case 4:
									System.out.print("ENTER NEW PRICE : ");
									price=Float.parseFloat(bufferReader.readLine());
									break;
								}
								System.out.print("DO YOU WANT TO ALTER THE DETAILS OF SAME PRODUCT again?? PRESS ( yes or No) : ");
								repeated=bufferReader.readLine();

							}while(repeated.equalsIgnoreCase("Yes"));

							PreparedStatement ps1=connection.prepareStatement("update products set Name = ? where productID=?");
							ps1.setString(1, name);
							ps1.setString(2, Integer.toString(pid));

							PreparedStatement ps2=connection.prepareStatement("update products set Type = ? where productID=?");
							ps2.setString(1, type);
							ps2.setString(2, Integer.toString(pid));

							PreparedStatement ps3=connection.prepareStatement("update products set Quantity = ? where productID=?");
							ps3.setString(1, Integer.toString(qty));
							ps3.setString(2, Integer.toString(pid));

							PreparedStatement ps4=connection.prepareStatement("update products set Price = ? where productID=?");
							ps4.setString(1, Float.toString(price));
							ps4.setString(2, Integer.toString(pid));
							int nameUpdate,typeUpdate,quantityUpdate,priceUpdate;
							nameUpdate=ps1.executeUpdate();
							typeUpdate=ps2.executeUpdate();
							quantityUpdate=ps3.executeUpdate();
							priceUpdate=ps4.executeUpdate();

							if(nameUpdate>0 && typeUpdate>0 && quantityUpdate>0 && priceUpdate>0)
								System.out.println("PRODUCT INFO UPDATED SUCCESSFULLY !");

						}
					}
					if(flag==0)
						System.out.println("PRODUCT NOT FOUND !");
					System.out.print("DO YOU WANT TO MODIFY OTHER PRODUCT ? ( Type yes to continue or no to stop)");
					repeated_1=bufferReader.readLine();
					rs.beforeFirst();
				}while(repeated_1.equalsIgnoreCase("Yes"));
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
	private void searchProduct()throws IOException
	{
		int flag=0;
		int row=0;

		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		try
		{
			Connection connection=ShoppingCustomConnection.getCustConnection();
			PreparedStatement ps=connection.prepareStatement("select * from products",ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
			ResultSet rs=ps.executeQuery();
			//*******
			//for counting the number of rows in result set
			if(rs.last()) 
			{
				row=rs.getRow();
				rs.beforeFirst();
			}
			//*******
			if(row==0)
				System.out.println("NO PRODUCTS AVAIALABLE");
			else
			{
				do
				{
					System.out.println("Enter product ID to search : ");
					pid=Integer.parseInt(br.readLine());
					PreparedStatement ps1=connection.prepareStatement("select * from products where productID=?");
					ps1.setString(1,Integer.toString(pid));
					ResultSet rs1=ps1.executeQuery();
					flag=0;
					while(rs1.next())
					{
						if(Integer.parseInt(rs1.getString(1))==pid)
						{
							System.out.printf("Product ID   =  %-5d\n",Integer.parseInt(rs1.getString(1)));
							System.out.printf("Product Name =  %-20s\n",rs1.getString(2));
							System.out.printf("Product Type =  %-20s\n",rs1.getString(3));
							System.out.printf("Quantity     =  %-5d\n",Integer.parseInt(rs1.getString(4)));
							System.out.printf("Price        =  %-10f\n",Float.parseFloat(rs1.getString(5)));
							flag=1;
							break;
						}
					}
					if(flag==0)
						System.out.println("PRODUCT NOT FOUND !");
					System.out.print("DO YOU WANT TO SEARCH THE PRODUCT ? ( Type yes to continue or no to stop )");
					repeated=br.readLine();
				}while(repeated.equalsIgnoreCase("Yes"));
			}

		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		System.out.println();

	}
	private void removeProducts()throws IOException
	{
		BufferedReader bufferR=new BufferedReader(new InputStreamReader(System.in));
		int prodTotal=0;

		try
		{
			Connection connection=ShoppingCustomConnection.getCustConnection();
			PreparedStatement ps=connection.prepareStatement("delete from products where productID=?");
			do
			{
				System.out.print("Enter product ID which you want to delete : ");
				pid=Integer.parseInt(bufferR.readLine());
				ps.setString(1,Integer.toString(pid));
				prodTotal=ps.executeUpdate();
				if(prodTotal==0)
					System.out.println("PRODUCT NOT FOUND !");
				else
					System.out.println("PRODUCT DELETED SUCCESSFULLY !");
				System.out.print("Do you want to REMOVE the PRODUCT ?( Type yes to continue or no to stop )");
				repeated=bufferR.readLine();

			}while(repeated.equalsIgnoreCase("Yes"));

		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
	private void addProducts()throws IOException
	{
		int res;
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("*****************************************************\n");
		try
		{
			Connection connection=ShoppingCustomConnection.getCustConnection();
			PreparedStatement ps=connection.prepareStatement("insert into products(productID,Name,Type,Quantity,Price) values(?,?,?,?,?)");
			do
			{
				pid=setPid();
				System.out.println("Product ID = "+pid);
				System.out.print("Enter Name : ");
				name=br.readLine();
				System.out.print("Enter Type : ");
				type=br.readLine();
				System.out.print("Enter Quantity : ");
				qty=Integer.parseInt(br.readLine());
				System.out.print("Enter price : ");
				price=Float.parseFloat(br.readLine());
				ps.setString(1, Integer.toString(pid));
				ps.setString(2, name);
				ps.setString(3,type);
				ps.setString(4, Integer.toString(qty));
				ps.setString(5, Float.toString(price));
				res=ps.executeUpdate();

				if(res>0)
					System.out.println("PRODUCT ADDED SUCCESSFULLY !\n");

				System.out.print("Do you want to ADD the PRODUCT? ( Type yes to continue or no to stop )");
				repeated=br.readLine();

			}while(repeated.equalsIgnoreCase("Yes"));
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
	private void viewProducts()
	{
		int row=0;
		try
		{
			Connection connection=ShoppingCustomConnection.getCustConnection();
			PreparedStatement ps=connection.prepareStatement("select * from products",
					ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
			ResultSet rs=ps.executeQuery();
			//*******
			//for counting the number of rows in result set
			if(rs.last())
			{
				row=rs.getRow();
				rs.beforeFirst();
			}
			//*******
			if(row==0)
			{
				System.out.println("NO PRODUCTS AVAIALABLE !");
			}
			else
			{
				System.out.println("The products are : \n");
				System.out.println("****************************************************************************************************************************\n");
				System.out.printf("%-15s \t %-20s \t %-20s \t %-15s \t %-15s\n","Product ID","Name","Type","Quantity","Price");
				System.out.println("****************************************************************************************************************************\n");
				while(rs.next())
				{
					pid=Integer.parseInt(rs.getString("productID"));
					name=rs.getString("Name");
					type=rs.getString("Type");
					qty=Integer.parseInt(rs.getString("Quantity"));
					price=Float.parseFloat(rs.getString("Price"));
					System.out.printf("%-15d \t %-20s \t %-20s \t %-15d \t %-15f\n",pid,name,type,qty,price);
				}
				System.out.println("****************************************************************************************************************************\n");
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}

	private static int setPid()
	{
		int productIdStart=999;
		try
		{
			Connection connection=ShoppingCustomConnection.getCustConnection();
			PreparedStatement ps=connection.prepareStatement("select productID from products",
					ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
			ResultSet rs=ps.executeQuery();

			while(rs.next())
			{
				productIdStart=Integer.parseInt(rs.getString("productID"));
			}

		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return productIdStart+1; 
	}
}
